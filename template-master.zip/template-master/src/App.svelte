<script>
	import { onMount, onDestroy } from 'svelte';
    import Cookies from 'js-cookie/src/js.cookie.js'

   let books = [];

    const CSRF_TOKEN = Cookies.get('csrftoken');
    const SHOP_URL = getRef("shop-ref");
    const HOME_URL = getRef("home-ref");
    const BOOK_CR_URL = getRef("bookcr-ref");

    function getRef(id) {return document.getElementById(id).href;};

    onMount(async () => {
       const response = await fetch(SHOP_URL,  {
                                     headers: {
                                        'Accept': 'application/json, text-plain, */*',
                                        'X-Requested-With': 'XMLHttpRequest',
                                     }, });

       let book_json = await response.json();
        books = book_json['books']
        books = books
       console.log(books)
   });

</script>

<main>
	{#each books as item }
	<div class="col-md-3">
		<div class="item">
			<a href="."><img src="'/uploads/' + item.img" alt="img">
<!--						background-image:{'url(/static/shop/' + item.img + ')'}-->
			<h6>{item.author}</h6>
			<h6>{item.name}</h6></a>
			<h6><span class="price">{item.discount}</span> / <a href=".">Buy Now</a></h6>
		</div>
	</div>
	{/each}

</main>
<style>
	main {
		text-align: center;
		padding: 1em;
		max-width: 240px;
		margin: 0 auto;
	}

	h1 {
		color: #ff3e00;
		text-transform: uppercase;
		font-size: 4em;
		font-weight: 100;
	}

	@media (min-width: 640px) {
		main {
			max-width: none;
		}
	}
</style>
